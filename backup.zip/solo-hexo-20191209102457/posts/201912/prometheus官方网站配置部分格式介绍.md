title: prometheus 官方网站配置部分格式介绍
date: '2019-12-05 15:06:01'
updated: '2019-12-05 17:55:53'
tags: [prometheus, yaml]
permalink: /articles/2019/12/05/1575529561916.html
---
https://prometheus.io/docs/prometheus/latest/configuration/configuration/

配置文件这部分用作查询配置文件里的参数很有帮助，这里做一下记录。

## yaml
prometheus 配置文件是yaml格式。
yaml文件里只有两种数据格式， 列表与字典。
基础部分都是字典，  只有 - 横杠表示一个列表项。 如：
```
    kubernetes_sd_configs:
    - role: node
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
```
```
    kubernetes_sd_configs:
    - 
      role: node
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
```
```
    kubernetes_sd_configs:
      - role: node
        api_server: https://172.100.101.195:8443
        tls_config:
          ca_file: /home/qfpay/prometheus/ssl/cacert.pem
```

```
    kubernetes_sd_configs:
      - 
        role: node
        api_server: https://172.100.101.195:8443
        tls_config:
          ca_file: /home/qfpay/prometheus/ssl/cacert.pem
```
```
kubernetes_sd_configs: [{role: 'node', api_server: 'https://172.100.101.195:8443', tls_config: {ca_file: '/home/qfpay/prometheus/ssl/cacert.pem'}}]
```
上面这五种写法都一样。
- 横杠表示一个列表项的开始，注意：是列表项，不是整个列表。 它与后面的内容是两部分， 后面的`role`不是跟 `-` 一起的。

上面的`kubernetes_sd_configs`是一个字典的`key`， 他的`value`是一个列表项。
同时列表项的内容又是字典，每行都是一个字典key value对， 注意：只是字典里的一项，不是一个字典。
上面第五种的value的引号也可以不加。

主要理解 - 表示一个列表项就可以了， 其他的都是字典里的内容。

## prometheus config格式
#### 赋值占位符
![image.png](https://img.hacpai.com/file/2019/12/image-d4718c52.png)
配置文件里配置项的值的格式。
主要是`labelname`， 如果prometheus发现的label名称里有不在[a-zA-z_][a-zA-Z0-9_]*这个范围里的， 会用下划线代替。如：
```
kubernetes.io/hostname
```
就会变成
```
kubernetes_io_hostname
```
---

#### 
![image.png](https://img.hacpai.com/file/2019/12/image-cb6ed89a.png)
上面的`external_labels` 下面就是字典的key: value， [ ] 表示可选的意思，并不是列表。
 `<labelname>` 与 `<labelvalue>` 都是赋值占位符，直接写key : value的。

`<scrape_config>` 表示配置段的占位符，每一个都表示一个配置段。
 `- <scrape_config>`表示列表项，`- <filepath_glob> ... `整体表示可以写多个列表项，每一项表示一个配置段。
就成了下面这样。
```
- <scrape_config>
- <scrape_config>
- <scrape_config>
```
 
如：
![image.png](https://img.hacpai.com/file/2019/12/image-a91e101d.png)
每一个 `-` 表示`<scrape_config>`所代表的配置段。

点开以后就会发现这一层所有的配置参数。因为这里内容太多了，所以截图不全。
![image.png](https://img.hacpai.com/file/2019/12/image-38ec49df.png)

---

然后这些参数有的还有对应的下一级，如：
![image.png](https://img.hacpai.com/file/2019/12/image-bcf6ffdd.png)
这里又跟上面一样， 每个 `<static_config>` 都是一个列表项。

`<static_config>`的内容：

![image.png](https://img.hacpai.com/file/2019/12/image-113076d2.png)

![image.png](https://img.hacpai.com/file/2019/12/image-32de7c00.png)

`labels`  的下级就是字典，没什么说的。
`targets`的下级又是列表， 每个`host`是一个列表项。 
所有列表项除了用 `-` 表示，也可以直接写在列表里。意思是一样的。

![image.png](https://img.hacpai.com/file/2019/12/image-714cf920.png)




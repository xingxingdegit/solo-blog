title: k8s 二进制部署 七 (kube-scheduler)
date: '2019-11-23 14:49:45'
updated: '2019-11-23 14:49:45'
tags: [k8s, scheduler]
permalink: /articles/2019/11/23/1574491784972.html
---
scheduler 是调度器的意思，通过各种算法，把pod调度到对应的节点。

#### 流程：
###### 1、controller-manager发送创建pod的操作给apiserver,  apiserver存在etcd。
###### 2、scheduler watch apiserver获取到创建pod的信息，如创建几个pod， 还有资源之类的限制，主机限制等等。根据信息计算在哪些节点启动pod，  发送给apiserver。 apiserver存在etcd。
###### 3、kubectl watch apiserver 获取到本节点有pod操作， 然后执行操作。
删除操作也一样。

## 参数：
还是连接apiserver的127.0.0.1:8080非认证接口。就使用下面两个参数。
leader-elect 是为了高可用， 在多scheduler的环境，通过etcd实现资源锁的功能。
注意这个锁是节点的，不是每次请求都去加锁。
一般一个节点的scheduler获取到资源锁以后，只要不关闭， 就一直是持有状态。controller-manager的这个参数也是一样。

```
--master=http://127.0.0.1:8080 
--leader-elect
```

## 创建Unit文件:

```
vim /lib/systemd/system/kube-scheduler.service

[Unit]
Description=kubernetes scheduler

[Service]
ExecStart=/usr/local/k8s/bin/kube-scheduler \
--log-dir=/usr/local/k8s/logs \
--logtostderr=false \
--v=4 \
--master=http://127.0.0.1:8080 \
--leader-elect
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

然后启动就完事了。
```
[root@k8s-master logs]# tail kube-scheduler.WARNING 
Log file created at: 2019/11/23 01:22:37
Running on machine: k8s-master
Binary: Built with gc go1.12.10 for linux/amd64
Log line format: [IWEF]mmdd hh:mm:ss.uuuuuu threadid file:line] msg
W1123 01:22:37.468698   28900 authentication.go:249] No authentication-kubeconfig provided in order to lookup client-ca-file in configmap/extension-apiserver-authentication in kube-system, so client certificate authentication won't work.
W1123 01:22:37.468919   28900 authentication.go:252] No authentication-kubeconfig provided in order to lookup requestheader-client-ca-file in configmap/extension-apiserver-authentication in kube-system, so request-header client certificate authentication won't work.
W1123 01:22:37.468939   28900 authorization.go:146] No authorization-kubeconfig provided, so SubjectAccessReview of authorization tokens won't work.
W1123 01:22:37.493931   28900 authorization.go:47] Authorization is disabled
W1123 01:22:37.493936   28900 authentication.go:79] Authentication is disabled
```
这里的报错不影响， 是kube-scheduler里的启动参数， controller-manager也有， 还没有研究过， 不清楚说的匿名令牌访问是什么意思。



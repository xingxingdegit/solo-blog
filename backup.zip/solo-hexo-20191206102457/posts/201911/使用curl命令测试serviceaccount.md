title: 使用curl命令测试serviceaccount
date: '2019-11-25 11:15:06'
updated: '2019-11-25 11:27:46'
tags: [k8s, serviceaccount]
permalink: /articles/2019/11/25/1574651706002.html
---
使用curl命令测试serviceaccount。
-H 添加http head。  --cacert 指定认证apiserver的ca证书
```
[root@k8s-master k8s]# curl https://172.100.102.70:6443 -H "Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImpsR2hLMnZaNFFfR3lVTDU1M2ZralYzNXk4S3BqcHVtMUtmaUlIZm1RNVkifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJkZWZhdWx0Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6InRlc3QtdG9rZW4tOGNmOWQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoidGVzdCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6IjM5ZjNiMWFhLTRlOGEtNGI4OC1hMzI5LTNjYTljOGJiNGYwNiIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDpkZWZhdWx0OnRlc3QifQ.E_kGvisR4qMrVXhZJcQZd9NnI41Sj3b4jeo0X3tQB_juJxUK9kExksbEJVkJ5Whom6FdDpfMH0hedq2EZ5UjOTlFie2EHmLyBL3SuKlIpLWHfj2UW4d3m_u77pQAYUYKoKm_aNQGD55QL37lGwpa64Uzr84ezdRCBunzeZCC9sfMgfO7HfUJXLx4YUnhV7iyNqi3hEdx3ow7ScMWwKdSPM33bOHau-seU3P0Ce7Y6G9c9vfkKWYenT2HqrGGRcwx1ExsWodaZrDyk8h19H7Qyrxsm6ojP-lgl4xkW_aqSK_tJ2BrCg5_92nXJU18pLjJsEY5DL00tvQOFjUOB3KMrpTmdQ_an7c93nk0zD5p2MDuPe32A-XUmBav4uHJ4FVi8hGEheJSdunZvlz8nBVcdTzDrRaLeCG3eosF9ti0Nm-oaHkvGCm1PEHq8lIcWrXJ_13kdTTt5ztc_nSemOOLXjxjDhXYw8izCiIpzjaInOPAlw0xtCaj6jY3oPJVWTT89YfQZ2hAAaNlF4_LE1wHrBjD7Cl4_GBxOgHuyVM6_133U40iWoTQY0OK6Ht6QZYZcVEq6XFtxH3R5Gd2e21Qg-6PM07CJAfJAZdQ7SVNWMkHiuGcQ6i-Mrq09dh-2NOJaaYMr4qhYy-pfXV7FOsatysl2s0gKICQCBxzrJYGG80" --cacert ssl/cacert.pem
{
  "paths": [
    "/api",
    "/api/v1",
    "/apis",
    "/apis/",
    "/apis/admissionregistration.k8s.io",
    "/apis/admissionregistration.k8s.io/v1",
    "/apis/admissionregistration.k8s.io/v1beta1",
    "/apis/apiextensions.k8s.io",
    "/apis/apiextensions.k8s.io/v1",
    "/apis/apiextensions.k8s.io/v1beta1",
    "/apis/apiregistration.k8s.io",
    "/apis/apiregistration.k8s.io/v1",
    "/apis/apiregistration.k8s.io/v1beta1",
```

```
[root@k8s-master k8s]# url https://172.100.102.70:6443/version -H "Authorization: Bearer eyJhbGciOiJSUzI1NiIsImtpZCI6ImpsR2hLMnZaNFFfR3lVTDU1M2ZralYzNXk4S3BqcHVtMUtmaUlIZm1RNVkifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJkZWZhdWx0Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZWNyZXQubmFtZSI6InRlc3QtdG9rZW4tOGNmOWQiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoidGVzdCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6IjM5ZjNiMWFhLTRlOGEtNGI4OC1hMzI5LTNjYTljOGJiNGYwNiIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDpkZWZhdWx0OnRlc3QifQ.E_kGvisR4qMrVXhZJcQZd9NnI41Sj3b4jeo0X3tQB_juJxUK9kExksbEJVkJ5Whom6FdDpfMH0hedq2EZ5UjOTlFie2EHmLyBL3SuKlIpLWHfj2UW4d3m_u77pQAYUYKoKm_aNQGD55QL37lGwpa64Uzr84ezdRCBunzeZCC9sfMgfO7HfUJXLx4YUnhV7iyNqi3hEdx3ow7ScMWwKdSPM33bOHau-seU3P0Ce7Y6G9c9vfkKWYenT2HqrGGRcwx1ExsWodaZrDyk8h19H7Qyrxsm6ojP-lgl4xkW_aqSK_tJ2BrCg5_92nXJU18pLjJsEY5DL00tvQOFjUOB3KMrpTmdQ_an7c93nk0zD5p2MDuPe32A-XUmBav4uHJ4FVi8hGEheJSdunZvlz8nBVcdTzDrRaLeCG3eosF9ti0Nm-oaHkvGCm1PEHq8lIcWrXJ_13kdTTt5ztc_nSemOOLXjxjDhXYw8izCiIpzjaInOPAlw0xtCaj6jY3oPJVWTT89YfQZ2hAAaNlF4_LE1wHrBjD7Cl4_GBxOgHuyVM6_133U40iWoTQY0OK6Ht6QZYZcVEq6XFtxH3R5Gd2e21Qg-6PM07CJAfJAZdQ7SVNWMkHiuGcQ6i-Mrq09dh-2NOJaaYMr4qhYy-pfXV7FOsatysl2s0gKICQCBxzrJYGG80" --cacert ssl/cacert.pem
{
  "major": "1",
  "minor": "16",
  "gitVersion": "v1.16.2",
  "gitCommit": "c97fe5036ef3df2967d086711e6c0c405941e14b",
  "gitTreeState": "clean",
  "buildDate": "2019-10-15T19:09:08Z",
  "goVersion": "go1.12.10",
  "compiler": "gc",
  "platform": "linux/amd64"
```

title: prometheus 独立安装监控k8s
date: '2019-12-03 14:59:58'
updated: '2019-12-05 10:29:25'
tags: [k8s, prometheus]
permalink: /articles/2019/12/03/1575356398124.html
---
这里没有介绍配置参数的意思，只是为了说明配置的框架。

一般是有三方面数据需要监控：
#### 1、 pod性能： 
使用kubelet自带的/metrics/cadvisor接口监控， 收集pod的cpu 内存相关数据。
#### 2、 资源对象状态：
通过运行kube-state-metrics实现，收集pod 运行状态以及deployment,service,endpoint等等的信息。
#### 3、 主机性能：
使用prometheus的node-exporter， 收集主机信息。

还有`service`，`pod`, `endpoint`,`ingress`  都可以自动发现，  时间问题暂时不多说了， 大致配置都一样。

---

## 一、介绍
prometheus 一般有两种运行方式， 一种是在k8s集群里运行，一种是单独运行， 我个人是喜欢单独运行。
这里也只是介绍单独运行的， 主要配置都一样。

## 二、连接k8s
二进制下载包里有prometheus的yml文件， 里面有个prometheus-rbac.yaml文件，包含了prometheus访问k8s的权限， 我们只要这部分：
```
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: prometheus
  labels:
    kubernetes.io/cluster-service: "true"
    addonmanager.kubernetes.io/mode: Reconcile
rules:
  - apiGroups:
      - ""
    resources:
      - nodes
      - nodes/metrics
      - services
      - endpoints
      - pods
    verbs:
      - get
      - list
      - watch
  - apiGroups:
      - ""
    resources:
      - configmaps
    verbs:
      - get
  - nonResourceURLs:
      - "/metrics"
    verbs:
      - get
```
放文件里应用一下, 并创建一下clusterrolebinding。
```
[root@k8s-master1 ~]# kubectl apply -f prometheus-rbac.yml

[root@k8s-master1 ~]# kubectl create clusterrolebinding prometheus --clusterrole=prometheus --user=prometheus
clusterrolebinding.rbac.authorization.k8s.io/prometheus created
```
之后自己生成common name为prometheus的证书就可以了。

---

#### prometheus 这边

```
scrape_configs:
  - job_name: 'k8s-node-kubelet'
    kubernetes_sd_configs:
    - role: node
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
        cert_file: /home/qfpay/prometheus/ssl/prometheus.crt
        key_file: /home/qfpay/prometheus/ssl/prometheus.key
```

###### tls_configs配置：
这个配置可以用在job_name下级， 也可以用在kubernetes_sd_configs的下级。
上面tls_config需要在kubernetes_sd_configs里面。提供发现过程中的apiserver的证书认证。

在job_name的下级是用来在获取数据时使用的。在最下面获取apiserver metrics接口的数据的时候有配置。

---

配置中的证书就是上面授权的证书， ca是k8s 对外接口的ca。 我这里连得是负载均衡地址，所以端口是8443。


https://prometheus.io/docs/prometheus/latest/configuration/configuration/#kubernetes_sd_config
查看官方网站， 里面就有这些信息。

## 三、添加监控
其实就上面的配置，已经可以发现东西了。
![image.png](https://img.hacpai.com/file/2019/12/image-bba1fb6d.png)

![image.png](https://img.hacpai.com/file/2019/12/image-9c3b57c0.png)

![image.png](https://img.hacpai.com/file/2019/12/image-6ea9987e.png)

只是默认是访问的是以http访问10250端口。这里需要使用relabel_configs改一下。
修改端口10250为10255，kubelet的http端口是10255。  
如果只是修改http为https又会遇到认证问题。
https://prometheus.io/docs/prometheus/latest/configuration/configuration/#relabel_config
官方网站已经说明了__address__标签是负责target的host:port， 所以就修改这个标签。
```
scrape_configs:
  - job_name: 'k8s-node-kubelet'
    kubernetes_sd_configs:
    - role: node
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
        cert_file: /home/qfpay/prometheus/ssl/prometheus.crt
        key_file: /home/qfpay/prometheus/ssl/prometheus.key
    relabel_configs:
    - source_labels: [ __address__ ]
      target_label: __address__
      regex: (.*):10250
      replacement: $1:10255
      action: replace
```
这里把原标签的__address__替换成__address__，就是覆盖了。 
regex: 正则匹配，只要匹配成功。  就可以修改了。  replacement为替换以后的值。  action动作就是replace。
具体的配置还是要看看其他的文档，然后对比官方文档。

![image.png](https://img.hacpai.com/file/2019/12/image-e3fc64a0.png)
可以看到target的端口已经是10255了，状态看到一个也是up了， 其他的也都是up。  发现__address__标签还是10250， 这是正常的， 因为relabel修改标签就是在获取目标数据的时候修改的， 而标签是在发现目标以后就已经确定的。

---

上面只是监控的kubelet， 监控pod性能的接口不是/metrics。  所以还要添加一个监控pod的。
流程跟上面一样，再添加一个job_name， 只要在添加一个修改__metrics_path__标签就可以。
#### pod性能
```
  - job_name: 'k8s-node-pod'
    kubernetes_sd_configs:
    - role: node
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
        cert_file: /home/qfpay/prometheus/ssl/prometheus.crt
        key_file: /home/qfpay/prometheus/ssl/prometheus.key
    relabel_configs:
    - source_labels: [ __address__ ]
      target_label: __address__
      regex: (.*):10250
      replacement: $1:10255
      action: replace
    - source_labels: [ __metrics_path__ ]
      target_label: __metrics_path__
      regex: (^/metrics$)
      replacement: $1/cadvisor
      action: replace
```

---

#### 主机
```
  - job_name: 'k8s-node-host'
    kubernetes_sd_configs:
    - role: node
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
        cert_file: /home/qfpay/prometheus/ssl/prometheus.crt
        key_file: /home/qfpay/prometheus/ssl/prometheus.key
    relabel_configs:
    - source_labels: [ __address__ ]
      target_label: __address__
      regex: (.*):10250
      replacement: $1:9100
      action: replace
```

---

#### kube-state-metrics
因为是连接的service地址， 固定不变的， 直接static_configs。
```
  - job_name: 'k8s-resource-info'
    static_configs:
    - targets: ['10.0.243.185:8080']
```

---

#### k8s-apiserver
所有主节点都添加了kubernetes.io/k8s-apiserver标签
```
kubectl label node k8s-master1 kubernetes.io/k8s-apiserver=true
```

ptometheus配置：
其实就多了一个job_name下的tls_config，如果没有这个，prometheus在访问metrics接口的时候会认证失败。
然后多了一个keep的relabel_configs， 表示只需要符合规则的 target。
```
  - job_name: 'k8s-apiserver'
    tls_config:
      ca_file: /home/qfpay/prometheus/ssl/cacert.pem
      cert_file: /home/qfpay/prometheus/ssl/prometheus.crt
      key_file: /home/qfpay/prometheus/ssl/prometheus.key
    kubernetes_sd_configs:
    - role: node
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
        cert_file: /home/qfpay/prometheus/ssl/prometheus.crt
        key_file: /home/qfpay/prometheus/ssl/prometheus.key
    relabel_configs:
    - source_labels: [__meta_kubernetes_node_label_kubernetes_io_k8s_apiserver]
      regex: ^true$
      action: keep
    - source_labels: [ __address__ ]
      target_label: __address__
      regex: (.*):10250
      replacement: $1:6443
      action: replace
    - source_labels: [ __scheme__ ]
      target_label: __scheme__
      regex: ^http$
      replacement: https
      action: replace
```

#### coredns
这里从pod里获取的，需要从指定的namespace发现pod, 不然数量太多了。
```
  - job_name: 'CoreDNS'
    kubernetes_sd_configs:
    - role: pod
      api_server: https://172.100.101.195:8443
      tls_config:
        ca_file: /home/qfpay/prometheus/ssl/cacert.pem
        cert_file: /home/qfpay/prometheus/ssl/prometheus.crt
        key_file: /home/qfpay/prometheus/ssl/prometheus.key
      namespaces:
        names:
        - kube-system
    relabel_configs:
    - source_labels: [__meta_kubernetes_pod_container_name,__meta_kubernetes_pod_container_port_number]
      separator: ;
      regex: coredns;9153
      action: keep
```



## 四、prometheus的标签与k8s的标签。
还有annotation.
还有如果有的节点不需要监控， 可以给k8s添加一些标签或是annotations,   prometheus发现的target里面都有这些信息。

![image.png](https://img.hacpai.com/file/2019/12/image-f18dfd2c.png)

只是对比一下就可以发现，k8s里的.(点), / (斜杠)  都变成了下划线，横线也会变成下划线。
因为label命名只能是： [a-zA-Z_][a-zA-Z0-9_]* 
可能所有不符合命名规则的都会以下划线代替。
如:
![image.png](https://img.hacpai.com/file/2019/12/image-016f943f.png)

![image.png](https://img.hacpai.com/file/2019/12/image-471efe11.png)








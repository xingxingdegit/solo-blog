title: filebeat发往es的索引不对
date: '2019-11-19 18:53:41'
updated: '2019-11-19 18:57:29'
tags: [filebeat, es]
permalink: /articles/2019/11/19/1574160820980.html
---
###### 从7.0版开始，Filebeat在连接到支持生命周期管理的群集时默认使用索引生命周期管理。Filebeat自动加载默认策略，并将其应用于Filebeat创建的任何索引。
https://www.elastic.co/guide/en/beats/filebeat/current/ilm.html

#### 问题:
filebeat 配置好以后，发往es的索引还是filebeat默认的索引。
filebeat配置如下：
![image.png](https://img.hacpai.com/file/2019/11/image-ba1c304c.png)
日志：
![image.png](https://img.hacpai.com/file/2019/11/image-ebd41de8.png)
es:
![image.png](https://img.hacpai.com/file/2019/11/image-be7bf483.png)

#### 解决很简单：
就是上面的网址，索引由索引生命周期管理功能控制了。使用或者直接关闭。
![image.png](https://img.hacpai.com/file/2019/11/image-6e6b04f8.png)


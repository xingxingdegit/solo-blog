title: k8s-apiserver
date: '2019-10-30 16:12:02'
updated: '2019-11-06 07:25:39'
tags: [k8s, kubernetes]
permalink: /articles/2019/10/30/1572423121991.html
---
暂时没有整理，贴一下参数。

```
/usr/local/k8s/bin/kube-apiserver --logtostderr=false --log-dir=/usr/local/k8s/logs --v=4 --etcd-servers=https://172.100.102.70:2379 --etcd-cafile=/usr/local/k8s/ssl/cacert.pem --etcd-certfile=/usr/local/k8s/ssl/apiserver.crt --etcd-keyfile=/usr/local/k8s/ssl/apiserver.key --bind-address=172.100.102.70 --advertise-address=172.100.102.70 --secure-port=6443 --tls-cert-file=/usr/local/k8s/ssl/apiserver.crt --tls-private-key-file=/usr/local/k8s/ssl/apiserver.key --enable-bootstrap-token-auth --authorization-mode=RBAC,Node --client-ca-file=/usr/local/k8s/ssl/cacert.pem --service-cluster-ip-range=10.0.0.0/16 --service-node-port-range=20000-50000 --allow-privileged --kubelet-https --enable-admission-plugins=NamespaceLifecycle,LimitRanger,ServiceAccount,ResourceQuota,NodeRestriction --service-account-key-file=/usr/local/k8s/ssl/cacert.pem
```
参数介绍：
```
--logtostderr                    # 是否把日志打印到标准错误输出
--log-dir                        # 日志目录
--service-account-key-file       # 验证service account token 的，  controller-manager还有一个生成service account token的。
--etcd-servers                   # etcd
--etcd-cafile                    # etcd连接的证书
--etcd-certfile
--etcd-keyfile
--bind-address                    # 监听的有安全连接(https)的ip地址。
--advertise-address               # 要广播给集群成员的ip地址， 必须要能够访问， 如果为空，就是--bind-address的地址，如果都没有，则为机器默认地址。
--secure-port                     # https安全连接的端口
--tls-cert-file                   # apiserver https的证书。
--tls-private-key-file
--enable-bootstrap-token-auth     # 使用引导令牌需要启用这个
--authorization-mode              # 认证模式， 一般是: RBAC, Node
--client-ca-file                  # 用来认证客户端的ca证书。
--service-cluster-ip-range        # service ip 范围, 不能与pod ip范围冲突。
--service-node-port-range         # service nodePort 范围
--allow-privileged                # 是否允许特权容器。
--kubelet-https                   # 使用https连接kubelet,  默认就是true
--enable-admission-plugins        # 准入控制插件。

```
--enable-bootstrap-token-auth:   启用引导令牌。 允许kubelet在引导是自动从apiserver获取签署的TLS证书，kubelet需要--bootstreap-kubeconfig配置文件设置令牌。  因为为每个kubelet设置证书太麻烦，所以才有了这种方式。

启用以后，可以在kube-system命名空间创建bootstrap.kubernetes.io/token类型的secret来创建token，用于kubelet bootstreap配置文件里的token。  

secret里面的auth-extra-groups可能是添加额外的组认证， 这些组也要有下面的权限。

  

还需要在kube-controller-manager里面注意--controllers参数(启用的控制器)， 需要启用bootstrapsigner，  默认是启用所有的， 一般不用管。

TLS引导以及相关配置：  [https://kubernetes.io/docs/reference/command-line-tools-reference/kubelet-tls-bootstrapping/](https://kubernetes.io/docs/reference/command-line-tools-reference/kubelet-tls-bootstrapping/)  

bootstrap令牌验证:  [https://kubernetes.io/docs/reference/access-authn-authz/bootstrap-tokens/](https://kubernetes.io/docs/reference/access-authn-authz/bootstrap-tokens/)  

bootstreap-kubeconfig 配置文件与kubeconfig一样， 只是users部分使用的是token.

  

从上面的网址中抄出来的权限设置方式： 

bootstrap的token没有明显的user和group,  bootstrap令牌认知，k8s内置的是system:bootstrappers和system:nodes组，

1、 授权kubelet穿件CSR证书请求文件， 需要给system:bootstrappers组绑定k8s内置的system:node-bootstrapper 角色。

2、 设置CSR是可以签署的，  需要给system:bootstrappers组绑定k8s内置的system:certificates.k8s.io:certificatesigningrequests:nodeclient 角色。

3、 授权kubelet能够自动续订证书，  需要给system:nodes组绑定k8s内置的system:certificates.k8s.io:certificatesigningrequests:selfnodeclient角色.

  

这种自动获取证书的方式，也不仅仅只有bootstrap令牌，  也可以用其他的验证方式，如serviceaccount token, 如统一的证书， 只要权限设置正确，kubelete的bootstrp-kubeconfig设置好就可以用了。

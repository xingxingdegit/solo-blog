title: k8s 认证流程
date: '2019-10-30 16:31:11'
updated: '2019-11-21 14:22:59'
tags: [k8s, kubernetes]
permalink: /articles/2019/10/30/1572424271739.html
---
用户合法认证----->  权限认证(如:rbac, node) --------->  访问控制。

#### 合法性，确认用户：
```
(--requestheader-client-ca-file AND --requestheader-allowed-names) OR --client-ca-file OR --service-account-key-file OR --token-auth-file
```
有多个认证方式：
--requestheader-client-ca-file AND --requestheader-allowed-names
--client-ca-file
--service-account-key-file
--token-auth-file

#### 权限验证：
确认用户是否有资源的操作权


rbac现在很常用，用来给用户授权， 给客户端授权。
node专用于kubelet的，可以授权kubelet可以读取node上的pod信息，如从apiserver获取本节点的新增，删除， 修改pod的操作。
rbac, node,  webhook， ABAC

#### 访问控制
这个请求是否可以执行， 有没有超出限额， 给请求自动作调整等，有各种各样的 准入控制 插件负责。

比如： node 授权kubelet 可以修改pod和node以及状态信息，启用NodeRestriction访问控制以后，kubelet就只能修改本节点和本节点pod的信息和状态。

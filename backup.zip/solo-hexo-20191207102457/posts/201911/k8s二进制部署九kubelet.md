title: k8s 二进制部署 九 (kubelet)
date: '2019-11-23 16:35:55'
updated: '2019-11-24 15:24:01'
tags: [k8s, kubelet]
permalink: /articles/2019/11/23/1574498155825.html
---
### 注意

###### 关闭 swap

不关在启动 kubelet 与 kube-proxy 的时候会提示，不支持 swap 环境启动。
![image.png](https://img.hacpai.com/file/2019/11/image-97096ba0.png)


###### firewalld,  selinux 也关闭。

###### 系统时区

---

## 一、介绍

kubelet 是主要的工作节点程序，功能如下：

* ###### 注册节点。
* ###### 从 apiserver 监测已分配给节点的 pod 信息, 或者是从本地配置中获取 pod 信息， 启动 pod。
* ###### 执行容器健康检查。探针。
* ###### 挂载 pod 需要的挂在卷。
* ###### 下载 pod 需要的 secret,  configmap， 并挂载。
* ###### 监控容器和节点资源。
* ###### 发送节点状态和 pod 状态给 apiserver。
* ###### 提供/metrics/cAdvisor 监控接口。

## 二、参数

```
--address                 # 监听地址
--bootstrap-kubeconfig    # 指定bootstrap认证文件， 通过bootstrap获取自动颁发的证书。在kube-apiserver参数部分有详细介绍。
--cert-dir                # 自动获取的证书会放到这个目录
--cgroup-driver           # 指定cgroup驱动，需要跟docker的一致，(systemd,  cgroupfs)。
--cluster-dns             # 集群dns的ip。
--cluster-domain          # 集群dns中的域名后缀，需要与安装的集群dns中设置的一致。
--kubeconfig              # 指定连接apiserver的信息。 如果指定的文件不存在，并且bootstrap-kubeconfig有设置， 会自动根据获取到的证书生成这个文件。
--root-dir                # 设置kubelet的根目录， emptyDir临时卷是在这个目录下。
--pod-infra-container-image    # 指定pause镜像的地址，不指定就是默认的海外地址。
```

## 三、文件

也就是目录结构还有执行文件。conf 目录下的文件一会 er 生成。

```
[root@k8s-node1 k8s]# tree
.
├── bin
│   ├── kubelet
│   └── kube-proxy
├── conf
├── logs
└── ssl

4 directories, 2 files
```

## 四、Unit

```
[Unit]
Description=kubelet
Requires=docker.service

[Service]
ExecStart=/usr/local/k8s/bin/kubelet\
--address=172.100.102.71 \
--bootstrap-kubeconfig=/usr/local/k8s/conf/bootstrp-kubeconfig \
--cert-dir=/usr/local/k8s/ssl \
--cgroup-driver=systemd \
--cluster-dns=10.0.0.2 \
--cluster-domain=cluster.local \
--kubeconfig=/usr/local/k8s/conf/kubeconfig \
--log-dir=/usr/local/k8s/logs \
--logtostderr=false \
--v=4 \
--root-dir=/usr/local/kubelet-data \
--pod-infra-container-image=registry.cn-beijing.aliyuncs.com/yangxingxing/pause:3.1
Restart=on-failure

[Install]
WantedBy=multi-user.target
```
这里的 pause 镜像是从 google 云下载并上传到阿里的，可以使用。

## 五、配置自动获取证书
如果不需要自动获取证书就不需要这一步
详细流程：
https://kubernetes.io/docs/reference/command-line-tools-reference/kubelet-tls-bootstrapping/
bootstrap令牌验证。
https://kubernetes.io/docs/reference/access-authn-authz/bootstrap-tokens/
这里的bootstrap是一种认证方式。非必须，也可以使用其他认证方式。

---

kubelect参数的bootstrip-kubeconfig是引导获取证书的意思
而bootstrap认证是一种认证方式，专门用于kubelet引导启动时认证的。

---

#### 1、kube-apiserver需要做的
https://www.yxingxing.net/articles/2019/10/30/1572423121991.html

###### （1）需要启用enable-bootstrap-token-auth参数。只有使用bootstrap令牌验证的方式需要。
```
--enable-bootstrap-token-auth
```
如果使用token的方式就是：
```
--token-auth-file=FILENAME
```
如果使用token的方式， 官方网站显示组名是固定的system:bootstrappers。
如：
令牌， 用户名， 用户id,   组名。
```
02b50b05283e98dd0fd71db496ef01e8,kubelet-bootstrap,10001,"system:bootstrappers"
```

---
无论是引导令牌认证，还是token认证，授权都一样。

###### （2）授权kubelet创建CSR证书签名请求。
![image.png](https://img.hacpai.com/file/2019/11/image-676780fd.png)
直接把创建clusterrolebinding的内容直接复制下来并应用就可以。
```
[root@k8s-master init]# cat kubelet-csr.yaml 
# enable bootstrapping nodes to create CSR
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: create-csrs-for-bootstrapping
subjects:
- kind: Group
  name: system:bootstrappers
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: ClusterRole
  name: system:node-bootstrapper
  apiGroup: rbac.authorization.k8s.io

[root@k8s-master init]# kubectl apply -f kubelet-csr.yaml
clusterrolebinding.rbac.authorization.k8s.io/create-csrs-for-bootstrapping created
[root@k8s-master init]# 
```

###### （3）授权可以签发证书。
其中又有两种方式：

---

1、节点还没有证书，只能使用bootstrip令牌认证，这就需要跟上面一样给system:bootstrappers组授权。

页面翻译的，能理解就行。创建一个clusterrolebinding。
![image.png](https://img.hacpai.com/file/2019/11/image-cbd746c4.png)
```
[root@k8s-master init]# cat kubelet-new-crt.yaml
# Approve all CSRs for the group "system:bootstrappers"
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: auto-approve-csrs-for-group
subjects:
- kind: Group
  name: system:bootstrappers
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: ClusterRole
  name: system:certificates.k8s.io:certificatesigningrequests:nodeclient
  apiGroup: rbac.authorization.k8s.io

[root@k8s-master init]# kubectl apply -f kubelet-new-crt.yaml
clusterrolebinding.rbac.authorization.k8s.io/auto-approve-csrs-for-group created
[root@k8s-master init]# 
```

---

2、节点有证书，需要续订证书，就给节点组，赋予可以续订证书的权限。

![image.png](https://img.hacpai.com/file/2019/11/image-d5acc8d0.png)
```
[root@k8s-master init]# cat kubelet-renew-crt.yaml
# Approve renewal CSRs for the group "system:nodes"
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: auto-approve-renewals-for-nodes
subjects:
- kind: Group
  name: system:nodes
  apiGroup: rbac.authorization.k8s.io
roleRef:
  kind: ClusterRole
  name: system:certificates.k8s.io:certificatesigningrequests:selfnodeclient
  apiGroup: rbac.authorization.k8s.io

[root@k8s-master init]# kubectl apply -f kubelet-renew-crt.yaml
clusterrolebinding.rbac.authorization.k8s.io/auto-approve-renewals-for-nodes created
[root@k8s-master init]# 
```
权限创建完了。

---

#### 2、controller-manager需要做的
其实就是启动的时候加上三个参数以及开启bootstrap控制器。
```
--cluster-signing-cert-file=
--cluster-signing-cert-file
--experimental-cluster-signing-duration
```
controller-manager 需要启动bootstrapsigner控制器。默认是启动的。

#### 3、kubelet
* 存储生成的密钥和证书的路径（可选，可以使用默认值）
* `kubeconfig`尚不存在的文件的路径；它将引导文件放在这里
*  `bootstrap-kubeconfig`文件的路径，用于提供服务器和引导程序凭据的URL，例如引导程序令牌

在上面的启动参数里都已经加上了。
现在就剩创建bootstrap-kubeconfig文件了。

---

#### 4、配置bootstrap-kubeconfig文件
这个文件与一般的kubeconfig文件格式一样， 只是 user 部分使用 bootstrap-token。   所以主要是创建bootstrap-token。

###### 说明bootstrap-token格式
https://kubernetes.io/docs/reference/access-authn-authz/bootstrap-tokens/
![image.png](https://img.hacpai.com/file/2019/11/image-07342065.png)
就是这个格式，如果能打开上面的网址， 里面都有介绍。 要求大致如下:

---

* token必须类似 abcdef.0123456789abcdef 这种格式，必须匹配正则表达式`[a-z0-9]{6}\.[a-z0-9]{16}`，令牌的第一部分是“token-id”，后面部分是tokne-secret。

* type 必须为`bootstrap.kubernetes.io/token`，
* name 必须为`bootstrap-token-<token id>`,
* 必须在 `kube-system`  namespace 中。

---

其他说明:
* `expiration`字段控制令牌的到期时间。过期的令牌在用于身份验证时将被拒绝，并在ConfigMap签名期间被忽略。到期值使用RFC3339编码为绝对UTC时间。
* controller-manager启用 `tokencleaner`控制器 能够自动删除过期的令牌。
* `usage-bootstrap-*`表示这是用于什么。必须将值设置为`true`启用。有下面两个。

* `usage-bootstrap-authentication` 表示令牌可以用作承载令牌向API服务器进行身份验证。 
* `usage-bootstrap-signing`指示令牌可用于签署 `cluster-info`ConfigMap。

* `auth-extra-groups`:  需要额外的组做认证， 这个具体是什麽意思还没有搞明白，可能是所填入的组也需要有相关权限。

---

###### 创建bootstrip-token
生成一些随机值:
```
[root@k8s-master init]# openssl rand -base64 20
yiCm94HtA5vm1Y6Nt1oWcN3wfRE=
```
摘出来几个做token-id,  和 token-secret，  大写变成小写就可以。
```
[root@k8s-master init]# cat bootstrip-token.yaml
apiVersion: v1
kind: Secret
metadata:
  # Name MUST be of form "bootstrap-token-<token id>"
  name: bootstrap-token-yicm94
  namespace: kube-system

# Type MUST be 'bootstrap.kubernetes.io/token'
type: bootstrap.kubernetes.io/token
stringData:

  # Token ID and secret. Required.
  token-id: yicm94
  token-secret: hta5vm1y6nt1owcn

  # Expiration. Optional.
  expiration: 2019-11-28T03:22:11Z

  # Allowed usages.
  usage-bootstrap-authentication: "true"
  usage-bootstrap-signing: "true"

[root@k8s-master init]# kubectl apply -f bootstrip-token.yaml
secret/bootstrap-token-yicm94 created
[root@k8s-master init]# 
```
注意过期时间。

接下来直接把kubectl使用的config文件或者自己新创建一个文件， 放到kubelect启动参数bootstrap-kubeconfig所指定的文件。
删除原来文件user部分的证书认证，把token放进去。

![image.png](https://img.hacpai.com/file/2019/11/image-e366b2aa.png)

成了这个样子就可以了。接下来就可以启动kubelet了。

---

另外： 上面的server 我这里没有连接vip， 因为还要安装hasproxy 或 nginx做负载均衡代理到后面的apiserver。 这里只是说明kubelet， 就不折腾了。


## 五、启动kubelet。
```
[root@k8s-node1 k8s]# tree
.
├── bin
│   ├── kubelet
│   └── kube-proxy
├── conf
│   └── bootstrp-kubeconfig
├── logs
└── ssl

4 directories, 3 files
```

```
[root@k8s-node1 conf]# systemctl start kubelet

[root@k8s-node1 k8s]# tree
.
├── bin
│   ├── kubelet
│   └── kube-proxy
├── conf
│   ├── bootstrp-kubeconfig
│   └── kubeconfig
├── logs
│   ├── kubelet.ERROR -> kubelet.k8s-node1.root.log.ERROR.20191124-020405.7817
│   ├── kubelet.INFO -> kubelet.k8s-node1.root.log.INFO.20191124-020344.7817
│   ├── kubelet.k8s-node1.root.log.ERROR.20191124-020405.7817
│   ├── kubelet.k8s-node1.root.log.INFO.20191124-020344.7817
│   ├── kubelet.k8s-node1.root.log.WARNING.20191124-020345.7817
│   └── kubelet.WARNING -> kubelet.k8s-node1.root.log.WARNING.20191124-020345.7817
└── ssl
    ├── kubelet-client-2019-11-24-02-03-44.pem
    ├── kubelet-client-current.pem -> /usr/local/k8s/ssl/kubelet-client-2019-11-24-02-03-44.pem
    ├── kubelet.crt
    └── kubelet.key

4 directories, 14 files
```

在master节点查看一下：
```
[root@k8s-master logs]# kubectl get nodes
NAME        STATUS   ROLES    AGE   VERSION
k8s-node1   Ready    <none>   52s   v1.16.2
```

---

另外： 上面是通过bootstrap-token的方式认证的，不清楚其他的认证方式，如：
证书的方式， 是不是需要固定组为system:bootstrappers,  然后也是按上面的方式给这个组授权。

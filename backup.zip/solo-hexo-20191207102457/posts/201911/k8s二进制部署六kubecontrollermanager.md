title: k8s 二进制部署 六 (kube-controller-manager)
date: '2019-11-23 11:53:24'
updated: '2019-11-23 11:53:24'
tags: [k8s]
permalink: /articles/2019/11/23/1574481204488.html
---
controller-manager是k8s集群中的控制中心，通过apiserver的watch接口实时获取资源的变化， 维持集群中资源状态为期望中的状态。
通过各种控制器controller管理各种特定的资源。如RC控制器就是控制pod的数量。
这里的RC控制器不是rc资源, 资源里的rc名称就是因为与RC控制器重名了，所以才改成ReplicaSet的。

参数在这里：
https://www.yxingxing.net/articles/2019/10/30/1572423306696.html
单独分出来就是为了以后有的参数搞明白了方面加上。

## 安装
这里的controller-manager直接连接apiserver的127.0.0.1:8080,  这个接口是非认证接口， 不需要为controller-manager添加证书， 如果连接6443的认证接口， 只要用集群CA创建证书，并且授权就可以。 这个没有尝试过，不太清楚授什么权限。

看一下k8s的目录：
```
[root@k8s-master k8s]# tree
.
├── bin
│   ├── kube-apiserver
│   ├── kube-controller-manager
│   └── kube-scheduler
├── logs
│   ├── kube-apiserver.ERROR -> kube-apiserver.k8s-master.root.log.ERROR.20191117-054754.25266
│   ├── kube-apiserver.INFO -> kube-apiserver.k8s-master.root.log.INFO.20191117-054752.25266
│   ├── kube-apiserver.k8s-master.root.log.ERROR.20191117-054754.25266
│   ├── kube-apiserver.k8s-master.root.log.INFO.20191117-054752.25266
│   ├── kube-apiserver.k8s-master.root.log.WARNING.20191117-054753.25266
│   └── kube-apiserver.WARNING -> kube-apiserver.k8s-master.root.log.WARNING.20191117-054753.25266
└── ssl
    ├── cacert.pem
    ├── cakey.pem
    ├── kube-apiserver.crt
    └── kube-apiserver.key

3 directories, 13 files
```
执行文件都已经在了。
###### 需要把集群ca的key与证书放到ssl目录里， 用来自动给kubelet生成证书。 以及生成serviceaccount token。
***给kubelet生成证书的是这三个参数：***
cluster-signing-cert-file， cluster-signing-key-file， experimental-cluster-signing-duration。   制定证书，key， 以及证书有效期。
因为apiserver使用CA证书认证客户端， 所以这里需要使用相同的CA证书已KEY。
如果不需要自动颁发kubelet证书， 要手动创建， 这3个参数就不需要了。

***生成serviceaccount是这个：***
service-account-private-key-file
因为apiserver那里也是使用ca证书来认证serviceaccount， 所以这里也需要相同CA。这几种认证方式没有交叉， 只要与apiserver用来认证的CA证书对应起来就行。

#### 创建Unit文件
```
vim /lib/systemd/system/kube-controller-manager.service


[Unit]
Description=kubernetes controller manager

[Service]
ExecStart=/usr/local/k8s/bin/kube-controller-manager \
--log-dir=/usr/local/k8s/logs \
--logtostderr=false \
--v=4  \
--leader-elect \
--address=127.0.0.1 \
--cluster-signing-cert-file=/usr/local/k8s/ssl/cacert.pem \
--cluster-signing-key-file=/usr/local/k8s/ssl/cakey.pem \
--experimental-cluster-signing-duration=87600h0m0s \
--root-ca-file=/usr/local/k8s/ssl/cacert.pem \
--service-account-private-key-file=/usr/local/k8s/ssl/cakey.pem \
--cluster-name=kubenetes-op \
--master=http://127.0.0.1:8080
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

  
## 启动
```
systemctl start kube-controller-manager
```
```
[root@k8s-master logs]# ll kube-controller-manager.*
lrwxrwxrwx. 1 root root    71 Nov 22 22:30 kube-controller-manager.ERROR -> kube-controller-manager.k8s-master.root.log.ERROR.20191122-223050.28787
lrwxrwxrwx. 1 root root    70 Nov 22 22:30 kube-controller-manager.INFO -> kube-controller-manager.k8s-master.root.log.INFO.20191122-223049.28787
-rw-r--r--. 1 root root   462 Nov 22 22:30 kube-controller-manager.k8s-master.root.log.ERROR.20191122-223050.28787
-rw-r--r--. 1 root root 84464 Nov 22 22:32 kube-controller-manager.k8s-master.root.log.INFO.20191122-223049.28787
-rw-r--r--. 1 root root  2013 Nov 22 22:30 kube-controller-manager.k8s-master.root.log.WARNING.20191122-223050.28787
lrwxrwxrwx. 1 root root    73 Nov 22 22:30 kube-controller-manager.WARNING -> kube-controller-manager.k8s-master.root.log.WARNING.20191122-223050.28787
```

```
[root@k8s-master logs]# tail kube-controller-manager.ERROR
Log file created at: 2019/11/22 22:30:50
Running on machine: k8s-master
Binary: Built with gc go1.12.10 for linux/amd64
Log line format: [IWEF]mmdd hh:mm:ss.uuuuuu threadid file:line] msg
E1122 22:30:50.988296   28787 core.go:201] failed to start cloud node lifecycle controller: no cloud provider provided
E1122 22:30:51.393569   28787 core.go:78] Failed to start service controller: WARNING: no cloud provider provided, services of type LoadBalancer will fail
```
因为默认启动了所有控制器， 而service controller是管理公有云提供的LB的, 通过监听LoadBalancer类型的service，更新外部云平台的LB实例。
cloud node lifecycle controller ， 这个云节点生命周期控制器不清楚是干嘛用的，记得原来官网的二进制安装里有， 但是链接成404了， 之后在研究。

除了两个链接外部云平台的报错没有影响以外， controller-manager就算起来了。

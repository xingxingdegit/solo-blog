title: k8s 二进制部署 三  (docker)
date: '2019-10-28 22:43:23'
updated: '2019-11-23 19:26:48'
tags: [docker, k8s, kubernetes]
permalink: /articles/2019/10/28/1572273802994.html
---
## 一、 注意事项
在使用最新版本docker和overlay2存储驱动的情况下：  
使用centos或redhat要求内核 3.10.0-514或以上， 非centos需要使用4.0或以上。  
xfs文件系统需要ftype=1， 不然无法支持overlay, overlay2存储驱动。
ftype=1 表示支持 d_type,  d_type表示目录条目类型， 是文件系统数据结构中的一个字段， 因为xfs是可选的，所以要注意这个，  ext4应该默认就是支持的。


bridge-nf-call-iptables 与 bridge-nf-call-ip6tables 内核参数要开启，二层数据会发给iptables，应该是用于从二层直接转发数据。

docker 选择的最新版本，暂时测试没有发现问题。 线上使用需要使用稍微小一点的版本，以确保与k8s兼容。

## 二、安装
docker version: 19.03.3

关闭防火墙：
```
systemctl stop firewalld
systemctl disable firewalld
```
关闭selinux：
```
# 修改  SELINUX=disabled  ， 修改完最好直接重启，反正也是刚开始。
vim /etc/selinux/config     
setenforce 0
```
安装docker的官方文档： https://docs.docker.com/install/linux/docker-ce/centos/
docker官方的源在国内速度慢， 可以使用[阿里的源](https://opsx.alibaba.com/mirror)：https://opsx.alibaba.com/mirror

选择docker-ce，ce为社区版本，ee为企业版，会引导进入阿里的云栖社区，找到对应系统的源文件，这里是centos7的。 http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```
[root@k8s-node2 ~]# cd /etc/yum.repos.d
[root@k8s-node2 yum.repos.d]# wget http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
[root@k8s-node2 yum.repos.d]# yum install docker-ce -y
```
## 三、后续配置
安装完成以后需要简单的配置点东西
创建并编辑/etc/docker/daemon.json文件，是docker默认的配置文件。
dockerd --help可以看到。
```
--config-file string                      Daemon configuration file (default "/etc/docker/daemon.json")
```
```
# docker一次也没启动过可能没有docker目录。
mkdir /etc/docker; vim /etc/docker/daemon.json
```
daemon.json中所有参数在[这里](https://docs.docker.com/engine/reference/commandline/dockerd/)https://docs.docker.com/engine/reference/commandline/dockerd/, 页面的最下面，包含命令行的启动参数。
这里加一个镜像加速的站点， 都知道国内下载docker hub的网速情况。
这里是这个加速点的介绍： https://www.daocloud.io/mirror
最终会在daemon.json里面加上这个。
```
[root@k8s-node2 yum.repos.d]# cat /etc/docker/daemon.json
{"registry-mirrors": ["http://f1361db2.m.daocloud.io"]}
```
阿里也有加速点， 在阿里的容器镜像服务里面,  这里把阿里的也加上。

storage-driver 设置存储驱动，一般centos7新安装的docker默认都是使用overlay2，这里加上是为了防止出现意外。
```
{"registry-mirrors": ["http://f1361db2.m.daocloud.io","https://3oegfh0i.mirror.aliyuncs.com"],
 "storage-driver": "overlay2"}
```

在一些老版本docker使用overlay2可能会警告不能使用kerner 4.0之前的版本。
###### 需要在配置中加上跳过检查：
```
  "storage-opts": [
    "overlay2.override_kernel_check=true"
  ]
```
###### 数据存储目录 data-root   
可以放到命令行参数也可以放到daemon.json里， docker 的数据存储目录，默认是/var/lib/docker。包含 镜像，容器，存储卷， 状态信息。
```
  "data-root": "/mnt/docker-data",
```
#### 可选：
修改unit文件中docker的启动参数，使用systemd作为cgroup驱动， 之前好像在k8s官网看到过推荐用systemd。
```
#  添加--exec-opt native.cgroupdriver=systemd 到启动参数里面。
vim /lib/systemd/system/docker.service

[Unit]
Description=Docker Application Container Engine
Documentation=https://docs.docker.com
BindsTo=containerd.service
After=network-online.target containerd.service
Wants=network-online.target
Requires=docker.socket

[Service]
Type=notify
# the default is not to use systemd for cgroups because the delegate issues still
# exists and systemd currently does not support the cgroup feature set required
# for containers run by docker
# ****** append "--exec-opt native.cgroupdriver=systemd" to here.
ExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock --exec-opt native.cgroupdriver=systemd
ExecReload=/bin/kill -s HUP $MAINPID
TimeoutSec=0
RestartSec=2
Restart=always

# Note that StartLimit* options were moved from "Service" to "Unit" in systemd 229.
# Both the old, and new location are accepted by systemd 229 and up, so using the old location
# to make them work for either version of systemd.
StartLimitBurst=3

# Note that StartLimitInterval was renamed to StartLimitIntervalSec in systemd 230.
# Both the old, and new name are accepted by systemd 230 and up, so using the old name to make
# this option work for either version of systemd.
StartLimitInterval=60s

# Having non-zero Limit*s causes performance problems due to accounting overhead
# in the kernel. We recommend using cgroups to do container-local accounting.
LimitNOFILE=infinity
LimitNPROC=infinity
LimitCORE=infinity

# Comment TasksMax if your systemd version does not support it.
# Only systemd 226 and above support this option.
TasksMax=infinity

# set delegate yes so that systemd does not reset the cgroups of docker containers
Delegate=yes

# kill only the docker process, not all processes in the cgroup
KillMode=process

[Install]
WantedBy=multi-user.target
```

## 四、启动
直接systemctl 启动就行， 只是启动以后要确定一下docker info信息。
```
[root@k8s-node2 yum.repos.d]# systemctl start docker
Warning: docker.service changed on disk. Run 'systemctl daemon-reload' to reload units.
[root@k8s-node2 yum.repos.d]# systemctl daemon-reload
[root@k8s-node2 yum.repos.d]# systemctl stop docker
[root@k8s-node2 yum.repos.d]# systemctl start docker
[root@k8s-node2 yum.repos.d]# systemctl enable docker
Created symlink from /etc/systemd/system/multi-user.target.wants/docker.service to /usr/lib/systemd/system/docker.service.
```
```
[root@k8s-node2 yum.repos.d]# docker info
Client:
 Debug Mode: false

Server:
 Containers: 0
  Running: 0
  Paused: 0
  Stopped: 0
 Images: 0
 Server Version: 19.03.4
 Storage Driver: overlay2             #存储驱动
  Backing Filesystem: xfs
  Supports d_type: true                # 是否支持d_type
  Native Overlay Diff: true
 Logging Driver: json-file
 Cgroup Driver: systemd                 # cgroup 驱动
 Plugins:
  Volume: local
  Network: bridge host ipvlan macvlan null overlay
  Log: awslogs fluentd gcplogs gelf journald json-file local logentries splunk syslog
 Swarm: inactive
 Runtimes: runc
 Default Runtime: runc
 Init Binary: docker-init
 containerd version: b34a5c8af56e510852c35414db4c1f4fa6172339
 runc version: 3e425f80a8c931f88e6d94a8c831b9d5aa481657
 init version: fec3683
 Security Options:
  seccomp
   Profile: default
 Kernel Version: 3.10.0-957.27.2.el7.x86_64
 Operating System: CentOS Linux 7 (Core)
 OSType: linux
 Architecture: x86_64
 CPUs: 2
 Total Memory: 1.952GiB
 Name: k8s-node2
 ID: OABW:IKQQ:66K3:K6J5:C2EB:3BPX:5CEV:L5BZ:SGCT:J2TB:HUAJ:6RTQ
 Docker Root Dir: /var/lib/docker
 Debug Mode: false
 Registry: https://index.docker.io/v1/
 Labels:
 Experimental: false
 Insecure Registries:
  127.0.0.0/8
 Registry Mirrors:                       # 镜像加速
  http://f1361db2.m.daocloud.io/
  https://3oegfh0i.mirror.aliyuncs.com/
 Live Restore Enabled: false


WARNING: bridge-nf-call-iptables is disabled      # 需要开启内核中这个参数
WARNING: bridge-nf-call-ip6tables is disabled
```
查看/etc/sysctl.conf配置，发现 centos7 的sysctl配置被指到了/usr/lib/sysctl.d/目录下， 修改/usr/lib/sysctl.d/00-system.conf
```
vim /usr/lib/sysctl.d/00-system.conf

net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1

sysctl -p --system        # 执行sysctl -p --system以生效。
```

最后查看overlay模块是否加载：

```
[root@k8s-node2 ~]# lsmod | grep overlay
overlay                71964  0
```

overlay 是系统的一个文件系统类型， docker 的 overlay  , overlay2 都是使用系统的overlay文件系统， 使用mount命令可以测试。如：
```
mount -t overlay overlay -o lowerdir=low,upperdir=upper,workdir=work merged
```


其他k8s-node节点都是一样安装。k8s-master节点这里直接用systemd来启动, 不需要docker。

title: flannel 问题
date: '2019-11-13 15:33:38'
updated: '2019-11-13 15:33:38'
tags: [待分类]
permalink: /articles/2019/11/13/1573630418728.html
---
1、提示注册网络失败， 操作不支持。
```
I1113 15:27:58.554775   57441 main.go:386] Found network config - Backend type: vxlan
I1113 15:27:58.554872   57441 vxlan.go:120] VXLAN config: VNI=1 Port=0 GBP=false DirectRouting=false
E1113 15:27:58.556920   57441 main.go:289] Error registering network: operation not supported
I1113 15:27:58.557045   57441 main.go:366] Stopping shutdownHandler...
```
系统不支持vxlan模块。

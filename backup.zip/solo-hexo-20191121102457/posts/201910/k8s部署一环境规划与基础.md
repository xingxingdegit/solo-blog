title: k8s部署 一 (环境规划与基础)
date: '2019-10-26 11:45:52'
updated: '2019-10-29 11:12:00'
tags: [k8s, kubernetes]
permalink: /articles/2019/10/26/1572061552442.html
---
#### 一、上图
###### 节点情况：
![image.png](https://img.hacpai.com/file/2019/10/image-14f22feb.png)

这里的vip只是为了后面的扩展，管理节点要实现高可用。
###### 服务流程：
![image.png](https://img.hacpai.com/file/2019/10/image-7c96939b.png)
###### pod创建的数据流程图（关于操作资源的，安装可以忽略)
下面这个是从书上截下来的。都不知道应不应该放这里。
> kubernetes权威指南(第四版)
![image.png](https://img.hacpai.com/file/2019/10/image-6999a443.png)


#### 二、基本情况
##### 集群是否存活相关的服务
###### etcd
k8s 的数据存储中心，数据交换中心。这里还用来存储flannel的信息。

k8s-master节点安装kube-apiserver、kube-controller-manager、kube-scheduler
他们都属于控制类服务。
###### kube-apiserver
提供HTTP Rest接口以及入口认证、授权、访问控制等集群安全机制。是集群内各个服务模块之间的中心枢纽。

###### k8s-controller-manager
控制器的总和，包含各种控制器， 以前还考虑过是否把controller拆开，最终可能是考虑到增加复杂性没有拆开。
还是权威指南第四版：
> Controller Manager 内部 包含 Replication Controller、 Node Controller、 ResourceQuota Controller、 Namespace Controller、 ServiceAccount Controller、 Token Controller、 Service Controller 及 Endpoint Controller 这 8 种 Controller， 每种 Controller 都 负责 一种 特定 资源 的 控制 流程， 而 Controller Manager 正是 这些 Controller 的 核心 管理者。
龚正 等. Kubernetes权威指南：从Docker到Kubernetes实践全接触 (Kindle 位置 3640-3643). 电子工业出版社. Kindle 版本. 

###### k8s-scheduler
调度器，通过各种算法，把pod调度到对应的节点。

##### 工作节点
k8s-node 包括 kubelet, kube-proxy。
###### kubelet
运行容器，注册进apiserver， 定期向apiserver反应节点情况。 提供外部可访问的监控接口/metrics与/metrics/cadvisor，用来展示kubelet自己的情况和pod的资源使用情况。
###### kube-proxy
控制service资源的负载均衡，通过watch apiserver的service与endpoint等资源修改iptables规则或ipvs规则，让访问ClusterIP的请求正确的转发到后端的pod上。

###### flannel
flannel不是k8s-node的服务，但是每台node都需要跑， 也有类似的服务可以替换，如：ovs, calico。 flannel比较简单，稳定性也不错，市场也不小。

#### 三、软件下载链接
k8s: https://github.com/kubernetes/kubernetes/releases
k8s: https://storage.googleapis.com/kubernetes-release/release/v1.15.5/kubernetes-server-linux-amd64.tar.gz
etcd: https://github.com/etcd-io/etcd/releases
flannel: https://github.com/coreos/flannel/releases


#### k8s官方文档：
> 官方网站文档： https://kubernetes.io/zh/docs
> 官方词汇表： https://kubernetes.io/zh/docs/reference/glossary/?fundamental=true


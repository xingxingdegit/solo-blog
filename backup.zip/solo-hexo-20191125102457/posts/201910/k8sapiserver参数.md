title: k8s-apiserver 参数
date: '2019-10-30 16:12:02'
updated: '2019-11-24 12:56:22'
tags: [k8s, kubernetes]
permalink: /articles/2019/10/30/1572423121991.html
---


```
/usr/local/k8s/bin/kube-apiserver --logtostderr=false --log-dir=/usr/local/k8s/logs --v=4 --etcd-servers=https://172.100.102.70:2379 --etcd-cafile=/usr/local/k8s/ssl/cacert.pem --etcd-certfile=/usr/local/k8s/ssl/apiserver.crt --etcd-keyfile=/usr/local/k8s/ssl/apiserver.key --bind-address=172.100.102.70 --advertise-address=172.100.102.70 --secure-port=6443 --tls-cert-file=/usr/local/k8s/ssl/apiserver.crt --tls-private-key-file=/usr/local/k8s/ssl/apiserver.key --enable-bootstrap-token-auth --authorization-mode=RBAC,Node --client-ca-file=/usr/local/k8s/ssl/cacert.pem --service-cluster-ip-range=10.0.0.0/16 --service-node-port-range=20000-50000 --allow-privileged --kubelet-https --enable-admission-plugins=NamespaceLifecycle,LimitRanger,ServiceAccount,ResourceQuota,NodeRestriction --service-account-key-file=/usr/local/k8s/ssl/cacert.pem
```
参数介绍：
```
--logtostderr                    # 是否把日志打印到标准错误输出
--log-dir                        # 日志目录
--etcd-servers                   # etcd
--etcd-cafile                    # 用来认证etcd的ca证书
--etcd-certfile                   # 用来连接etcd的证书。
--etcd-keyfile
--bind-address                    # 监听的有安全连接(https)的ip地址。
--advertise-address               # 要广播给集群成员的ip地址， 必须要能够访问， 如果为空，就是--bind-address的地址，如果都没有，则为机器默认地址。
--secure-port                     # https安全连接的端口
--tls-cert-file                   # apiserver https的证书。
--tls-private-key-file
--enable-bootstrap-token-auth     # 使用引导令牌需要启用这个
--authorization-mode              # 授权认证模式， 一般是: RBAC, Node
--service-cluster-ip-range        # service ip 范围, 不能与pod ip范围冲突。
--service-node-port-range         # service nodePort 范围
--allow-privileged                # 是否允许特权容器。
--kubelet-https                   # 使用https连接kubelet,  默认就是true
--master-service-namespace        # kubernetes service放到哪个namespace,  默认default。

# 准入控制
--admission-control                    # 使用enable-admission-plugins 或 disable-admission-plugins代替， 未来版本会删除这个参数。
--enable-admission-plugins        # 启用的准入控制插件。
--disable-admission-plugins        # 关闭的准入插件。

# 认证方式，不是authorization-mode授权那个。是第一层的认证。
--client-ca-file                  # 用来认证客户端的ca证书。
--requestheader-client-ca-file    # 用来认证客户端的ca证书， 认证通过以后，还要查看客户端的common name 是否包含在requestheader-allowed-names指定的列表里。
--requestheader-allowed-names     # 与requestheader-client-ca-file一起提供认证。
--service-account-key-file        # 验证service account token 的，  controller-manager还有一个生成service account token的。
--token-auth-file                 # 可以使用token文件认证。
# 上面的认证方式是'或'的关系, 只要有一种认证通过就行。
# (--requestheader-client-ca-file AND --requestheader-allowed-names) OR --client-ca-file OR --service-account-key-file OR --token-auth-file

# 扩展api相关，所指定的数据会写入到kube-system namespace的extension-apiserver-authentication configmap里。
# 认证方式里的requestheader-client-ca-file 与 requestheader-allowed-names 也要使用。
--proxy-client-cert-file                     # apiserver连接别人的证书，用于让别人认证自己。
--proxy-client-key-file
--requestheader-extra-headers-prefix=X-Remote-Extra-
--requestheader-group-headers=X-Remote-Group
--requestheader-username-headers=X-Remote-User
```
---
#### requestheader-client-ca-file， client-ca-file
--requestheader-client-ca-file 与 --client-ca-file的不同就是前者还要通过--requestheader-allowed-names。
一般情况下， --requestheader-client-ca-file与--requestheader-allowed-names用来认证扩展的api服务，
就是创建kind: APIService的服务，如 metrics-server就是这样的。
--client-ca-file 是认证一般用户的。  
--requestheader-client-ca-file 与 --client-ca-file 需要使用不同的CA，因为他们的认证方式是这个样子的：  
(--requestheader-client-ca-file  and  --requestheader-allowed-names) or --client-ca-file  
如果使用相同的ca， 会导致--requestheader-client-ca-file认证通过， 然后就会去判断--requestheader-allowed-names。

---

#### enable-bootstrap-token-auth

--enable-bootstrap-token-auth:   启用引导令牌。 允许kubelet在引导是自动从apiserver获取签署的TLS证书，kubelet需要--bootstreap-kubeconfig配置文件设置令牌。  因为为每个kubelet设置证书太麻烦，所以才有了这种方式。

启用以后，可以在kube-system命名空间创建bootstrap.kubernetes.io/token类型的secret来创建token，用于kubelet bootstreap配置文件里的token。  

secret里面的auth-extra-groups可能是添加额外的组认证， 这些组也要有下面的权限。

  

还需要在kube-controller-manager里面注意--controllers参数(启用的控制器)， 需要启用bootstrapsigner，  默认是启用所有的， 一般不用管。

TLS引导以及相关配置：  [https://kubernetes.io/docs/reference/command-line-tools-reference/kubelet-tls-bootstrapping/](https://kubernetes.io/docs/reference/command-line-tools-reference/kubelet-tls-bootstrapping/)  

bootstrap令牌验证:  [https://kubernetes.io/docs/reference/access-authn-authz/bootstrap-tokens/](https://kubernetes.io/docs/reference/access-authn-authz/bootstrap-tokens/)  

bootstreap-kubeconfig 配置文件与kubeconfig一样， 只是users部分使用的是token.

  

从上面的网址中抄出来的权限设置方式： 

bootstrap的token没有明显的user和group,  使用的是k8s内置的system:bootstrappers组和system:nodes组，所以给这两个组授权就可以了。

1、 授权kubelet创建CSR证书请求文件， 需要给system:bootstrappers组绑定k8s内置的system:node-bootstrapper 角色。

2、 设置CSR是可以签署的，  需要给system:bootstrappers组绑定k8s内置的system:certificates.k8s.io:certificatesigningrequests:nodeclient 角色。

3、 授权kubelet能够自动续订证书，  需要给system:nodes组绑定k8s内置的system:certificates.k8s.io:certificatesigningrequests:selfnodeclient角色.

  

这种自动获取证书的方式，也不仅仅只有bootstrap令牌，  也可以用其他的验证方式，如serviceaccount token, 如统一的证书， 只要权限设置正确，kubelete的bootstrp-kubeconfig设置好就可以用了。

title: k8s configmap
date: '2019-11-14 12:01:45'
updated: '2019-11-14 12:02:31'
tags: [k8s, configmap]
permalink: /articles/2019/11/14/1573704105136.html
---
因为configmap挂载为卷的时候会覆盖目录， 这里主要记录使用subPath挂载为文件。
### 一、先创建configmap
```
[root@k8s-master1 configmap]# ls
db.conf  server.yaml
[root@k8s-master1 configmap]# kubectl create configmap testconf --from-file=db.conf --from-file=server.yaml -n test
configmap/testconf created
[root@k8s-master1 configmap]#
```
上面也可以直接在上级目录用一个--from-file指定这两个文件所在的目录。

### 二、一般情况下的挂载
```
     spec:
      containers:
      - image: harbor.atest.pub/system/centos:7
        name: mytest
        imagePullPolicy: Always
        args: ['/bin/bash', '-c', 'while true;do echo hello world;sleep 2;done']
        volumeMounts:
        - name: test
          mountPath: /opt/data

      volumes:
      - name: test
        configMap:
          name: testconf
```
volumes里直接指定configMap的名称， volumeMounts直接引用，不加任何其他参数。
进入容器查看一下挂载情况：
![image.png](https://img.hacpai.com/file/2019/11/image-50b7e410.png)
这里的data目录是挂载的根目录， 不管原来有什么都会被覆盖。
而且如果有其他的内容也是以这样的挂载方式，会覆盖data目录之前挂载的内容。

### 三、subPath， 不会覆盖目录。
```
[root@k8s-master1 configmap]# kubectl explain deployment.spec.template.spec.containers.volumeMounts.subPath
KIND:     Deployment
VERSION:  apps/v1

FIELD:    subPath <string>

DESCRIPTION:
     Path within the volume from which the container's volume should be mounted.
     Defaults to "" (volume's root).
```
可以看到subPath默认是"", 表示挂载的是根。 上面mountPath指定的位置就是挂载点的根目录，挂载内容全放到根里面。
###### 测试subPath。
```
        volumeMounts:
        - name: test
          mountPath: /opt/data/server.yaml
          subPath: server.yaml
        - name: test
          mountPath: /opt/data/db.conf
          subPath: db.conf

      volumes:
      - name: test
        configMap:
          name: testconf
```
要注意，指定subPath以后，所指定的mountPath就不是挂载的根了， 而是subPath所指定的文件，这个configmap里有两个文件，所以要写两个mountPath。
进入容器查看：
![image.png](https://img.hacpai.com/file/2019/11/image-c8bdde04.png)
文件内容就是configmap里面对应的subPath。

### 四、volumes里的item。
items提供了configmap中需要挂载的文件，如果configmap里有多个文件，只想挂载一个。
在挂载的时候还可以修改configmap里文件名称。
###### 1、只挂载一个文件，并且改一下名字。
```
        volumeMounts:
        - name: test
          mountPath: /opt/data

      volumes:
      - name: test
        configMap:
          name: testconf
          items:
          - key: db.conf
            path: db.test
```
![image.png](https://img.hacpai.com/file/2019/11/image-d75d3023.png)

###### 2、挂载所有文件，修改名称
```
        volumeMounts:
        - name: test
          mountPath: /opt/data

      volumes:
      - name: test
        configMap:
          name: testconf
          items:
          - key: db.conf
            path: db.test
          - key: server.yaml
            path: server.yy
```
![image.png](https://img.hacpai.com/file/2019/11/image-4a5c199b.png)

###### 3、有subPath的情况
因为在指定subPath的情况下，mountPath指定的挂载点不是挂载跟，而是实际的挂载的文件，名称是自己指定的。所以items里修改名称就不需要了。 然后mountPath又可以只挂载configmap里的某一个文件。
他们有些功能看起来是相同的。这里只是来个一起使用的例子。
```
        volumeMounts:
        - name: test
          mountPath: /opt/data/db.conf
          subPath: db.test
        - name: test
          mountPath: /opt/data/server.yaml
          subPath: server.yy

      volumes:
      - name: test
        configMap:
          name: testconf
          items:
          - key: db.conf
            path: db.test
          - key: server.yaml
            path: server.yy
```
subPath需要使用item中path的名称。
![image.png](https://img.hacpai.com/file/2019/11/image-ba943e19.png)


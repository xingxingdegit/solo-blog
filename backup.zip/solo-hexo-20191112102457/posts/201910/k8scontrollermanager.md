title: k8s-controller-manager
date: '2019-10-30 16:15:06'
updated: '2019-11-06 07:25:28'
tags: [k8s, kubernetes]
permalink: /articles/2019/10/30/1572423306696.html
---
```
/usr/local/k8s/bin/kube-controller-manager --log-dir=/usr/local/k8s/logs --logtostderr=false --v=4 --service-cluster-ip-range=10.0.0.0/16 --leader-elect --address=127.0.0.1 --cluster-signing-cert-file=/usr/local/k8s/ssl/cacert.pem --cluster-signing-key-file=/usr/local/k8s/ssl/cakey.pem --experimental-cluster-signing-duration=87600h0m0s --root-ca-file=/usr/local/k8s/ssl/cacert.pem --service-account-private-key-file=/usr/local/k8s/ssl/cakey.pem --cluster-name=kubenetes-qfpay --master=http://127.0.0.1:8080
```

```
--logtostderr   # 日志
--log-dir
--v

--allocate-node-cidrs                      # 是否为节点pod分配网段, 跟云环境配合的，不需要使用flannel提供网络的那种。
--cluster-cidr                             # 分配的pod的网段。  需要--allocate-node-cidrs, 好像是给节点分配cidr 地址范围的 ，待测试。
--service-cluster-ip-range                 # 分配的service ip范围。  这个也是与云挂钩的。 一般不需要。 service ip 在apiserver那里指定了。

--leader-elect                             # 自动选举leader， 高可用环境使用。 拥有资源锁的controller才工作， 具体的机制应该是apiserver  watch  etcd, controller watch  apiserver,  没有锁的controller从apiserver收到变化不会做操作。  多个controller都会从apiserver收到变化， 但是只有一个会做操作。

# 端口监听
--address                                  # 不安全的监听端口所在地址。  一般controller都监听在127.0.0.1 , 用不到加密的端口。
--port                                     # 不安全的监听端口，  默认10252， 不需要认证， 提供/metrics监控接口。

--bind-address                             # 安全的监听端口所在地址
--secure-port                              # 安全的监听端口，  默认10257， 需要认证，提供/metrics监控接口。
--tls-cert-file                            # 安全端口所使用的证书
--tls-private-key-file

# 给节点颁发证书
--cluster-signing-cert-file                # 用于颁发自动生成集群节点所使用的证书的ca证书
--cluster-signing-key-file                 # 用于签署给集群节点自动颁发的证书的签名的ca私钥。
--experimental-cluster-signing-duration    # 签署的证书有效期， 默认8760h0m0s（1年）。

# service account
--root-ca-file                             # 如果指定，会把所指定的ca证书放到service account中。
--service-account-private-key-file         # 生成service account token用的。 一般使用的是ca的私钥。 apiserver还有个认证service account token的, 要与这个一样。

--cluster-name                             # 集群名称
--master                                   # 连接apiserver。  如果连接apiserver的非安全端口，会使用这个参数。 如果是安全端口，要使用kubeconfig来指定认证信息。

```

title: 回顾 Kubernetes 最近 6 个版本重点更新(转载)
date: '2019-11-06 10:26:47'
updated: '2019-11-06 10:26:47'
tags: [k8s, kubernetes]
permalink: /articles/2019/11/06/1573007207480.html
---
以下文章来源于DevOps技术栈 ，作者李振良

https://mp.weixin.qq.com/s/bNObMEBWihC3u6eViVT_gQ

因为从微信复制过来格式都乱了，还是来网址吧。

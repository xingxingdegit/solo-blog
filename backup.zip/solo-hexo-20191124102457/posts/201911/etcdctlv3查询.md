title: etcdctl v3 查询
date: '2019-11-21 11:24:28'
updated: '2019-11-21 11:24:28'
tags: [etcd]
permalink: /articles/2019/11/21/1574306668270.html
---
etcdctl命令自带的帮助太少了， 一些查询参数都没有，这里记录下。
https://github.com/etcd-io/etcd/tree/master/etcdctl

下面只有查询相关的， 另外为了方便查询都以--prefix前缀的方式查询，前缀查询里/字符不是/根目录，就是字符串是以/开头的。
我这里所有内容是v2的方式通过etcd网关存到v3的etcd里，所以key的名称跟v2的http路径差不多。

--endpoints=http://****, http://****, http://****

内容不多， 就测试了这几个。
### options:
###### --prefix
以前缀查询，下面查询以/为前缀的key。
```
./etcdctl --endpoints=****** get / --prefix
```    

###### --keys-only
前缀查询会把相同前缀的key以及key的内容都输出。
这个选项可以只显示key。
```
./etcdctl --endpoints=****** get / --prefix --keys-only
```

###### --limit
指定要输出的条目数量， 如：只查询3个。
```
$ ./etcdctl --endpoints=****** get / --prefix --limit 3
```

###### --hex
以十六进制输出, 以方便输出非打印字符。
```
./etcdctl --endpoints=****** get / --prefix --limit 3 --hex
```

###### -order <ascend|descend>
排序，升序 or  降序，   <ascend|descend>  参数用大小写都可以。
```
 ./etcdctl --endpoints=****** get / --prefix --limit 3 --order DESCEND
./etcdctl --endpoints=****** get / --prefix --limit 3 --order ascend
```

###### --from-key
输出大于或等于指定key名称的key名称。
```
./etcdctl --endpoints=****** get --from-key foo
```
还可以大于并且小于，直接get就可以。
输出key名称大于或等于foo并且小于foo3
```
./etcdctl --endpoints=****** get foo foo3
```
